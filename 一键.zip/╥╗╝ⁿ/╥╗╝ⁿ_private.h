/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef һ��_PRIVATE_H
#define һ��_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.3"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	3
#define COMPANY_NAME	"7.62Studio"
#define FILE_VERSION	"1.0.0.3"
#define FILE_DESCRIPTION	"���ٽ���frpc����"
#define INTERNAL_NAME	"Project 2145"
#define LEGAL_COPYRIGHT	"7.62Studio 2023"
#define LEGAL_TRADEMARKS	"frp quickset"
#define ORIGINAL_FILENAME	"frpcsetting"
#define PRODUCT_NAME	"frp�ͻ��˿�������"
#define PRODUCT_VERSION	"1.0.0.3"

#endif /*һ��_PRIVATE_H*/
